/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 9, 2018, 10:35 PM
 * Purpose:  Monthly payment
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const float HP=.005;//Half penny
const int   SHFT=100;//Shift

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mp,//Monthly payment in USD
          tl,//Total loan amount
          ti,//Total interest payed
          i,//Interest rate per month
          l,//Loan amount in USD
          m;//Number of monthly payments
    
    //Initialize Variables
    i=.01;//Interest is set to 1%/month (12%/year)
    l=10e3;//Loan amount is $10,000
    m=36;//Loan over 36 months
    
    //Process/Map inputs to outputs
    float u=pow(1+i,m);//utility variable for (1+i)^
    mp=(u*i*l)/(u-1);
    int ip=(mp+HP)*SHFT;//Half penny round up then truncate
    mp=static_cast<float>(ip)/SHFT;//Shift back to the right
    tl=mp*m;
    ti=tl-l;
    
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint
        <<"Loan amount     = $10000\n"
        <<"Loan length     = 36 months\n"
        <<"Interest        = 12%/year\n"
        <<"Monthly payment = $  "<<mp<<endl
        <<"Total loan      = $"<<tl<<endl
        <<"Total interest  = $ "<<ti<<endl;
    
    //Exit stage right!
    return 0;
}