/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 16, 2018, 11:18 PM
 * Purpose:  Math Tutor
 */

//System Libraries
#include <iostream>
#include <cstdlib>//Random number generator
#include <ctime>//Time library for random seed
#include <iomanip>//Format library
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short op1,op2,result,answer;
    
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Initialize variables
    op1=rand()%900+100;//Three digit number
    op2=rand()%1000;//Any 1-3 digit number
    
    //Process/map input to output
    result=op1+op2;
    
    //Output data
    cout<<"Test your addition skills, Solve the following\n";
    cout<<setw(5)<<op1<<endl;
    cout<<"+ "<<setw(3)<<op2<<endl;
    cout<<"------"<<endl<<(result>1000?" ":"  ");
    cin>>answer;
    cout<<(result==answer?"Correct":"Incorrect")<<endl; 
    
    //Exit stage right!
    return 0;
}