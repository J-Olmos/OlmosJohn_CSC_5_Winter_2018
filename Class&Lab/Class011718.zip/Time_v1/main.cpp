/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 17, 2018, 10:15 PM
 * Purpose: Time
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short cost,sTime,dur;
    char day,dm;

    //Initialize Variables
    cout<<"Calculate cost of a phone call\n"
        <<"Input the day a phone call was made\n"
        <<"Mo Tu We Th Fr Sa Su\n";
    cin>>day>>dm;
    cout<<"Input the start time in military format: \n"
        <<"1:30PM = 13:00\n";
    cin>>setw(2)>>sTime>>dm>>dm>>dm;
    cout<<"Input the duration of phone call in minutes: \n";
    cin>>dur;
    
    //Process/Map Inputs to Outputs
    if(day=='S'||day=='s'){
        cost=dur*15;
    }else if (sTime>=8&&sTime<18){
        cost=dur*40;
    }else {
        cost=dur*25;
    }

    //Output Data     
    cout<<fixed<<setprecision(2)<<showpoint
        <<"Cost = $"<<cost/100.0<<endl;
          
    //Exit stage right!
    return 0;
}