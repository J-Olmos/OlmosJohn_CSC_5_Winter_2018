/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 17, 2018, 10:15 PM
 * Purpose: Time
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short cost,dur,hrs,mins;
    string day,sTime;

    //Initialize Variables
    cout<<"Calculate cost of a phone call\n"
        <<"Input the day a phone call was made:\n"
        <<"Ex: Mo Tu We Th Fr Sa Su\n";
    cin>>day;
    cout<<"Input the start time in military format:\n"
        <<"Ex: 1:30PM = 13:00\n";
    cin>>sTime;
    cout<<"Input the duration of phone call in minutes:\n";
    cin>>dur;
    
    //Process/Map Inputs to Outputs
    hrs=(sTime[0]-48)*10+(sTime[1]-'0');
    if(day[0]=='S'||day[0]=='s'){
        cost=dur*15;
    }else if (hrs>=8&&hrs<18){
        cost=dur*40;
    }else {
        cost=dur*25;
    }

    //Output Data     
    cout<<fixed<<setprecision(2)<<endl
        <<"The phone call on "<<day<<" at "
        <<sTime<<" for "<<dur<<"minutes cost = $"<<cost/100.0f<<endl;
          
    //Exit stage right!
    return 0;
}