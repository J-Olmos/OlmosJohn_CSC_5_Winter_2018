/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 22, 2018, 11:00 PM
 * Purpose:  Convert to roman numerals
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short inN;
    unsigned char n1000,n100,n10,n1;
    
    //Initialize Variables
    cout<<"This program converts Numerals from Arabic to Roman.\n"
        <<"Input a number between 1 and 3000:\n";
    cin>>inN;
    
    //Process/Map inputs to outputs
    n1000=(inN-inN%1000)/1000;
    inN%=1000;
    n100=(inN-inN%100)/100;
    inN%=100;
    n10=(inN-inN%10)/10;
    inN%=10;
    n1=inN;
    
    //Display the 1000's place
    switch(n1000){
        case 3:cout<<"M";
        case 2:cout<<"M";
        case 1:cout<<"M";
    }
    
    //Display the 100's place
    switch(n100){
        case 9:cout<<"CM";break;
        case 8:cout<<"DCCC";break;
        case 7:cout<<"DCC";break;
        case 6:cout<<"DC";break;
        case 5:cout<<"D";break;
        case 4:cout<<"CD";break;
        case 3:cout<<"C";
        case 2:cout<<"C";
        case 1:cout<<"C";
    }
    
    //Display the 10's place
    switch(n10){
        case 9:cout<<"XC";break;
        case 8:cout<<"LXXX";break;
        case 7:cout<<"LXX";break;
        case 6:cout<<"LX";break;
        case 5:cout<<"L";break;
        case 4:cout<<"XL";break;
        case 3:cout<<"X";
        case 2:cout<<"X";
        case 1:cout<<"X";
    }
    
    //Display the 1's place
    switch(n1){
        case 9:cout<<"IX";break;
        case 8:cout<<"VIII";break;
        case 7:cout<<"VII";break;
        case 6:cout<<"VI";break;
        case 5:cout<<"V";break;
        case 4:cout<<"IV";break;
        case 3:cout<<"I";
        case 2:cout<<"I";
        case 1:cout<<"I";
    }
    
    //Output data
    cout<<"\nThe number you input = "
            <<static_cast<int>(n1000)
            <<static_cast<int>(n100)
            <<static_cast<int>(n10)
            <<static_cast<int>(n1);
    
    //Exit stage right!
    return 0;
}