/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 22, 2018, 11:00 PM
 * Purpose:  Convert to roman numerals
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
string rNC(unsigned short);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short inN;
    
    //Initialize Variables
    cout<<"This program converts Numerals from Arabic to Roman.\n"
        <<"Input a number between 1 and 3000: ";
    cin>>inN;
    
    //Display the result
    cout<<endl<<rNC(inN)<<endl;
    
    //Exit stage right!
    return 0;
}

/******************************************************************************/
/* Purpose: Convert an Arabic number to a Roman Numeral                       */
/* Input:  inN -> Integer from 1-300                                          */
/* Output: rN  -> String from Roman Numeral                                   */
/******************************************************************************/
string rNC(unsigned short inN) {
    //Validate input
    if (inN<1||inN>3000) {
        return "Input outside of range.";
    }
    
    //Declare Variables
    unsigned char n1000,n100,n10,n1;
    string rN;
    
    //Process/Map inputs to outputs
    n1000=(inN-inN%1000)/1000;
    inN%=1000;
    n100=(inN-inN%100)/100;
    inN%=100;
    n10=(inN-inN%10)/10;
    inN%=10;
    n1=inN;
    
    //Append the string with a number
    rN+=(n1000+48);/*******************************/
    rN+=(n100+48); /* Convert to character digits */
    rN+=(n10+48);  /*     (48-57 or 0-9)          */
    rN+=(n1+48);   /*******************************/
    rN+=" = ";
    
    //Display the 1000's place
    switch(n1000){
        case 3:rN+="M";
        case 2:rN+="M";
        case 1:rN+="M";
    }
    
    //Display the 100's place
    switch(n100){
        case 9:rN+="CM";break;
        case 8:rN+="DCCC";break;
        case 7:rN+="DCC";break;
        case 6:rN+="DC";break;
        case 5:rN+="D";break;
        case 4:rN+="CD";break;
        case 3:rN+="C";
        case 2:rN+="C";
        case 1:rN+="C";
    }
    
    //Display the 10's place
    switch(n10){
        case 9:rN+="XC";break;
        case 8:rN+="LXXX";break;
        case 7:rN+="LXX";break;
        case 6:rN+="LX";break;
        case 5:rN+="L";break;
        case 4:rN+="XL";break;
        case 3:rN+="X";
        case 2:rN+="X";
        case 1:rN+="X";
    }
    
    //Display the 1's place
    switch(n1){
        case 9:rN+="IX";break;
        case 8:rN+="VIII";break;
        case 7:rN+="VII";break;
        case 6:rN+="VI";break;
        case 5:rN+="V";break;
        case 4:rN+="IV";break;
        case 3:rN+="I";
        case 2:rN+="I";
        case 1:rN+="I";
    }
    return rN;
}