/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 2, 2018, 10:10 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const int PERCENT=100;//Percentage conversion

//Function Prototypes
float fv1(float,float,int);//Power function
float fv2(float,float,int);//log and exponent function
float fv3(float,float,int);//For-loop function
float fv4(float,float,int);//Recursion function
float fv1(float,float,float);//Overloaded function
float fv5(float,float,int=12);//Defaulted parameter
void  fv6(float &,float,int);//Pass by reference
int   fv7(float &,float,int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float pV,//Present value in dollars
          iR;//Investment rate in decimal
    int nC;//Number of compounding periods in months, years, etc.
    
    //Initialize Variables
    pV=100;//100 in savings
    nC=12;//12 years
    iR=static_cast<float>(72)/nC/PERCENT;//By rule of 72
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint
        <<"Present value = $"<<pV<<endl
        <<"Number of compounding periods = "<<nC<<" years \n"
        <<"Interest rate = "<<iR*PERCENT<<"%\n"
        <<"Future value Exp/Log function    = $"<<fv1(pV,iR,nC)<<endl
        <<"Future value Power function      = $"<<fv2(pV,iR,nC)<<endl
        <<"Future value For-Loop function   = $"<<fv3(pV,iR,nC)<<endl
        <<"Future value Recursion function  = $"<<fv4(pV,iR,nC)<<endl;
    float fC=nC;
    cout<<"Future value overloaded function = $"<<fv1(pV,iR,fC)<<endl
        <<"Future value defaulted function  = $"<<fv5(pV,iR)<<endl;
    float fp=pV;
    fv6(fp,iR,nC);
    cout<<"Future value Pass by reference   = $"<<fp<<endl;
    for(int loop=1;loop<=4;loop++){
        fp=pV;
        fv7(fp,iR,nC);
    }
    fp=pV;
    int nT=fv7(fp,iR,nC);
    cout<<"Future value Static variable     = $"<<fp<<endl;
    cout<<"Static function was called "<<nT<<" times";
    
    //Exit stage right!
    return 0;
}

float fv1(float p,float i,int n) {
    return p*pow(1+i,n);
}

float fv2(float p,float i,int n) {
    return p*exp(n*log(1+i));
}

float fv3(float p,float i,int n) {
    for(int y=1;y<=n;y++) {
        p*=(1+i);
    }
    return p;
}

float fv4(float p,float i,int n) {
    if(n<1)return p;//Base condition
    return fv4(p,i,n-1)*(1+i);
}

float fv1(float p,float i,float n) {
    return p*pow(1+i,n);
}

float fv5(float p,float i,int n) {
    for(int y=1;y<=n;y++) {
        p*=(1+i);
    }
    return p;
}

void fv6(float &fp,float i,int n) {
    for(int y=1;y<=n;y++) {
        fp*=(1+i);
    }
}

int fv7(float &fp,float i,int n) {
    static int count=0;
    for(int y=1;y<=n;y++) {
        fp*=(1+i);
    }
    return ++count;
}