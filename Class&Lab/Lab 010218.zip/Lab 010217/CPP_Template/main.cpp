/* 
 * File:   main.cpp
 * Author: John Olmos
 * Created on January 2, 2018, 1:20 PM
 * Purpose: Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map Inputs to Outputs
    
    //Output Data
    
    //Exit Stage Right
    return 0;
}

