/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 4, 2018, 1:20 PM
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float fedtx,statx,saletx,//Individual Government taxes in cents per gallon
          oiltx,// Oil profits in cents per gallon
          govpct,oilpct,//Tax percentage of total gas price
          gasttl;//Total gas price per gallon
    
    //Initialize Variables
    fedtx=.184f;//Fed tax per gal 
    statx=.36f;//State tax per gal 
    saletx=.22f;//Sales tax per gal 
    oiltx=.189f;//Oil profit per gal
    gasttl=2.75f;//Total gas price per gal
    
    //Process/Map inputs to outputs
    govpct=((fedtx+statx+saletx)/gasttl)*100;//Percent of gas spent on taxes
    oilpct=(oiltx/gasttl)*100;//Percent of gas spent on oil companies
    
    //Output data
    cout<<"Totals in USD"<<endl
        <<"Total Government taxes = $0.764/gallon"<<endl  
        <<"Total Oil profits = $0.189/gallon"<<endl  
        <<"Total Gas price = $2.75/gallon"<<endl
        <<"Total government taxes per gallon = "<<govpct<<"%"<<endl
        <<"Total oil profits per gallon = "<<oilpct<<"%"<<endl;
    
    //Exit stage right!
    return 0;
}