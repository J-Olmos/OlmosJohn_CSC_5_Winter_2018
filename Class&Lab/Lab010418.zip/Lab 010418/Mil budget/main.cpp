/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 4, 2018, 1:20 PM
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mil,tbdgt,pct; //
    
    //Initialize Variables
    mil=640e9f;//Total military budget 
    tbdgt=4.1e12f; //Total federal budget 
    
    //Process/Map inputs to outputs
    pct=(mil/tbdgt)*100; //Percent of budget spent on military
    
    //Output data
    cout<<"Budget totals in USD"<<endl
        <<"Total military budget = $640 Billion"<<endl  
        <<"Total federal budget = $4.1 Trillion"<<endl
        <<"Percent of budget spent on military = "<<pct<<"%"<<endl;
    
    //Exit stage right!
    return 0;
}