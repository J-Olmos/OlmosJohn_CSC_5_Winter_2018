/* 
 * File:   main.cpp
 * Author: John Olmos
 * Created on January 8, 2018, 12:20 PM
 * Purpose: Calculate interest impact on deficit
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float debt,//National debt
          fbdgt,//Federal budget
          intr,//Interest rate
          danger;//Interest payments as % of federal budget
    
    //Initialize Variables
    fbdgt=4.1e12;//Federal budget is 4.1 trillion USD
    debt=21.1e12;//National debt is 21.1 trillion USD                 
    
    //Process/Map inputs to outputs
    cout<<"Enter a percentage value for the interest rate.\n";
    cin>>intr;//User input for interest %            
    danger=(intr/100)*debt/fbdgt*100;
    
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint
        <<"An interest rate of "
        <<intr<<"% on the deficit would create a payment = "
        <<danger<<"% of the federal budget.\n";
    
    //Exit stage right!
    return 0;
}