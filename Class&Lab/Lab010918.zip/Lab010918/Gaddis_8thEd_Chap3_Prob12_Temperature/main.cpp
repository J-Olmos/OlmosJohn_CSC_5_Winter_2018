/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 9, 2018, 1:39 PM
 * Purpose:  Calculating temperature
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float degf,degc,degcc,//
          x1,x2,y1,y2;//
    
    //Initialize Variables
    x1=32;//Interpolation 32 degrees Fahrenheit
    x2=212;//Interpolation 212 degrees Fahrenheit
    y1=0;//Interpolation 0 degrees Centigrade
    y2=100;//Interpolation 100 degrees Centigrade
    
    //Input the temp to convert
    cout<<"Input the temperature in degrees Fahrenheit\n"
        <<"to convert to degrees Celsius\n";
    cin>>degf;
    
    //Process/Map inputs to outputs
    degc=(degf-32)*5/9;
    degcc=y1+(y2-y1)*(degf-x1)/(x2-x1);
    
    //Output data
    cout<<degf<<" degrees Fahrenheit = "
        <<degcc<<" degrees Celsius = "
        <<degc<<" degrees Celsius\n";
    
    //Exit stage right!
    return 0;
}