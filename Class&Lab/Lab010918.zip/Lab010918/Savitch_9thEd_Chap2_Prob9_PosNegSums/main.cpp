/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 9, 2018, 12:36 PM
 * Purpose:  Calculating positive and negative sums
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int number,nSum,pSum;//
    
    //Initialize Variables
    nSum=pSum=0;
    
    //Process/Map inputs to outputs
    cout<<"This program adds 10 numbers.\n"
        <<"It determines the negative, positive, and total sums.\n"
        <<"Input 10 numbers, 1 at a time.\n";
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    cin>>number;
    nSum+=number<0?number:0;
    pSum+=number>0?number:0;
    
    //Output data
    cout<<"The negative sum = "<<nSum<<endl
        <<"The positive sum = "<<pSum<<endl
        <<"The total sum = "<<nSum+pSum<<endl;
    
    //Exit stage right!
    return 0;
}