/* 
 * File:   main.cpp
 * Author: John Olmos
 * Created on January 10, 2018, 12:27 PM
 * Purpose: Calculate miles per gallon
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float tank,dist,mpg;//Tank size, max travel distance, and gas milage
    
    //Initialize Variables
    cout<<"Enter the number of gallons your car can hold. \n";
    cin>>tank;
    cout<<"Enter the number distance in miles your car "
        <<"can be driven on a full tank. \n";
    cin>>dist;    
    
    //Process/Map inputs to outputs
    mpg=dist/tank;
    
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint
        <<"Your estimated gas milage is = "<<mpg<<"mpg.\n";
    
    //Exit stage right!
    return 0;
}