/* 
 * File:   main.cpp
 * Author: John Olmos
 * Created on January 10, 2018, 1:54 PM
 * Purpose: Calculate the number of males and females in a class
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float ms,fs,sum,//Total male, total female, and sum of students in a class
          mPct,fPct;//Percentage of male and female students
    
    //Initialize Variables   
    sum=0;   
    
    cout<<"Enter the number of male students registered in class: ";
    cin>>ms;
    sum+=ms;
    cout<<"Enter the number of female students registered in class: ";
    cin>>fs;
    sum+=fs;
    
    //Process/Map inputs to outputs
    mPct=ms/sum*100;
    fPct=fs/sum*100;
    
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint
        <<"The percentage of males in the class is "<<mPct<<"%.\n"
        <<"The percentage of females in the class is "<<fPct<<"%.\n";
    
    //Exit stage right!
    return 0;
}