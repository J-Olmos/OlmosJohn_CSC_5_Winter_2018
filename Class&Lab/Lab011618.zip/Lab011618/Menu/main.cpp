/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 16, 2018, 11:18 PM
 * Purpose:  Menu
 */

//System Libraries
#include <iostream>
#include <cstdlib> //Random number generator
#include <ctime>   //Time library for random seed
#include <iomanip> //Format library
#include <cmath>   //math library
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int probNum;
    
    //Menu with input choices
    cout<<"Choose from the following menu:\n";
    cout<<"Problem 1 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 2 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 3 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 4 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 5 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 6 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 7 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 8 -> Gaddis_8thEd_Prob_\n";
    cout<<"Problem 9 -> Gaddis_8thEd_Prob_\n";
    cout<<"Type 1 to 9 only:\n";
    cout<<"\nProblem ";
    cin>>probNum;
    
    //Output the results
    switch(probNum){
        case 1: {
            //Declare Variables
            unsigned short op1,op2,result,answer;

            //Set the random number seed
            srand(static_cast<unsigned int>(time(0)));

            //Initialize variables
            op1=rand()%900+100; //Three digit number
            op2=rand()%1000;    //Any 1-3 digit number

            //Process/map input to output
            result=op1+op2;

            //Output data
            cout<<"Test your addition skills, Solve the following\n";
            cout<<setw(5)<<op1<<endl;
            cout<<"+ "<<setw(3)<<op2<<endl;
            cout<<"------"<<endl<<(result>1000?" ":"  ");
            cin>>answer;
            cout<<(result==answer?"Correct":"Incorrect")<<endl; 
            break;
        }
        case 2: {
            //Declare Variables
            unsigned int fi,fim1,fim2;

            //Set the random number seed
            srand(static_cast<unsigned int>(time(0)));

            //Initialize variables
            fim1=1; 
            fim2=1;
            cout<<fim2<<","<<fim1;    

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;


            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Process/map input to output
            fi=fim1+fim2;
            cout<<","<<fi;
            fim2=fim1;
            fim1=fi;

            //Comparison of the ratio of Fibonacci to Golden ratio
            cout<<"\nRatio = "<<1.0f*fim1/fim2<<endl;
            break;
        }
        case 3: {
            //Declare Variables
            float aproxE,term,x;
            int counter;

            //Initialize variables
            aproxE=1.0f; 
            counter=1;
            x=1.0f;
            term=x/counter++;    

            //Process/map input to output
            aproxE+=term;
            cout<<"e^"<<x<<" approximately = "<<aproxE<<endl;
            term*=x/counter++;

            //Process/map input to output
            aproxE+=term;
            cout<<"e^"<<x<<" approximately = "<<aproxE<<endl;
            term*=x/counter++;

            //Process/map input to output
            aproxE+=term;
            cout<<"e^"<<x<<" approximately = "<<aproxE<<endl;
            term*=x/counter++;


            //Process/map input to output
            aproxE+=term;
            cout<<"e^"<<x<<" approximately = "<<aproxE<<endl;
            term*=x/counter++;

            //Process/map input to output
            aproxE+=term;
            cout<<"e^"<<x<<" approximately = "<<aproxE<<endl;
            term*=x/counter++;

            //Comparison of the ratio of Fibonacci to Golden ratio
            cout<<"e^"<<x<<" exactly = "<<exp(x)<<endl;
            break;
        }
        case 4: {
            cout<<"Put problem 4 here"<<endl;
            break;
        }
        case 5: {
            cout<<"Put problem 5 here"<<endl;
            break;
        }
        case 6: {
            cout<<"Put problem 6 here"<<endl;
            break;
        }
        case 7: {
            cout<<"Put problem 7 here"<<endl;
            break;
        }
        case 8: {
            cout<<"Put problem 8 here"<<endl;
            break;
        }
        case 9: {
            cout<<"Put problem 9 here"<<endl;
            break;
        }
        default:cout<<"\nYou choose to exit\n";
        break;
    }
    
        
    
    //Exit stage right!
    return 0;
}