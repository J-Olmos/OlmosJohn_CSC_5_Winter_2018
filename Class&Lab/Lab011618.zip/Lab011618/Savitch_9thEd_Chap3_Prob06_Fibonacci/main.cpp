/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr & John Olmos
 * Created on January 16, 2018, 12:45 PM
 * Purpose:  Fibonacci sequence
 */

//System Libraries
#include <iostream>
#include <cstdlib> //Random number generator
#include <ctime>   //Time library for random seed
#include <iomanip> //Format library
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int fi,fim1,fim2;
    
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Initialize variables
    fim1=1; 
    fim2=1;
    cout<<fim2<<","<<fim1;    
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Process/map input to output
    fi=fim1+fim2;
    cout<<","<<fi;
    fim2=fim1;
    fim1=fi;
    
    //Comparison of the ratio of Fibonacci to Golden ratio
    cout<<"\nRatio = "<<1.0f*fim1/fim2<<endl;
    
    //Exit stage right!
    return 0;
}