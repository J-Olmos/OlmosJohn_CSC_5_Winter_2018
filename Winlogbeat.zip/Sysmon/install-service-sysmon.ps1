﻿# Install sysmon using SwiftOnSecurity configuartion file
.\sysmon.exe -accepteula -i sysmonconfig-export.xml